java -classpath .:./lib/* test.iotos.CollectNetworkInfoClient
